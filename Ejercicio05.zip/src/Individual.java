import java.util.*;

public class Pack extends Articulo {

	ArrayList<Articulo> listaArticulos = new ArrayList<Articulo>();

	double getPrecio() {
		double sumaTotal = 0;
		for (int i = 0; i < listaArticulos.size(); i++) {

			// accessing each element of array
			sumaTotal += listaArticulos.get(i).getPrecio();
			
		}
	}

}
