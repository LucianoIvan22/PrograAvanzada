
public class PackFijo extends Pack{

	double preciofijo;
	
	double getPrecio(){
		return preciofijo;
	}
	
}
