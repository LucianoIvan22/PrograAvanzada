
public class PackDescuento extends Pack{

	double porcentaje;
	
	double getPrecio(){
		return super.getPrecio() * porcentaje;
	}
}
