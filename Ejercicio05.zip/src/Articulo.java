import java.util.*;

public abstract class Articulo {

	double precio;
	String nombre;
	
	double getPrecio(){
		return this.precio;
	}
	
}
